# Portal 2 VR Mod

**Version: v5.3.0** — July 24, 2026

Open-source VR mod for Portal 2. Motion controls, 6DoF, room-scale, grabbable objects.
Built on the L4D2VR framework with DXVK (Vulkan renderer).

**One-stop-shop: No launch options required.** Just extract, launch Portal 2 normally,
the mod auto-detects SteamVR and applies all settings automatically.

---

## Quick Install

1. Download [Portal2VR_v5.3.0.zip](./Portal2VR_v5.3.0.zip)
2. Extract **all contents** into `steamapps\common\Portal 2` (merge folders)
3. Connect your headset and **start SteamVR**
4. **Launch Portal 2** normally from your Steam library

**That's it.** No launch options, no config tweaks, no SteamVR dashboard hunting.
The mod auto-detects SteamVR, forces windowed mode, and applies optimal settings.

---

## What's new in v5.3.0 — "One-Stop Shop"

| Feature | v5.2 (Previous) | v5.3.0 (Current) |
|---|---|---|
| Launch setup | Required `-insecure -window` + 8 cvars in Steam Launch Options | **Zero configuration** — auto-detects SteamVR |
| Window mode | Forced via `-window` flag | Auto-forced by DLL on launch |
| Graphics settings | Set via command-line cvars | Auto-applied via engine commands |
| VR detection | Required SteamVR running before launch | **Auto-detects** SteamVR at runtime |
| SteamVR missing | Error popup, game may crash | **Graceful fallback** — runs flat if no VR headset |
| Manifest | "Portal 2 VR" | "Portal 2 VR v5.3.0" with version info |
| Deployment | `bin\d3d9.dll` only | `bin\d3d9.dll` + **root `d3d9.dll`** for guaranteed loading |
| Build | Untested, manual deploy | **0 errors** CI-verified build |

---

## Repository Structure

```
Portal2VR/
├── L4D2VR/                    Source code (current v5.3.0)
│   ├── dllmain.cpp            Entry point — auto-VR detect, auto-windowing
│   ├── game.cpp               Engine hooks — auto-applied graphics settings
│   ├── vr.cpp                 VR core — silent fallback if no headset
│   ├── hooks.cpp              Source engine function hooks
│   ├── config.txt             Settings file (live-reloadable)
│   ├── manifest.vrmanifest    SteamVR app registration
│   └── SteamVRActionManifest/ SteamVR action bindings
├── dxvk/                      D3D9-to-Vulkan bridge (submodule)
├── thirdparty/                Dependencies (MinHook, OpenVR)
├── archive/
│   └── v0.2.0/                Original 0.2.0 release (reference)
├── Portal2VR_v5.3.0.zip       Pre-built release package
├── l4d2vr.sln                 Visual Studio solution
└── README.md                  This file
```

---

## How it works (auto-magic)

When Portal 2 launches:

1. **`d3d9.dll` loads** — placed in both `bin\` and root directory for guaranteed D3D9 interception
2. **Window auto-patched** — `FindWindow` + `SetWindowLongPtr` forces windowed mode at 1280x720
3. **Engine hooks initialize** — `InitL4D2VR` thread starts, hooks D3D9, engine, VGUI functions
4. **Auto-exec runs** — After 3 seconds, `mat_motion_blur`, `mat_vsync`, `mat_antialias`, and others are set to zero
5. **VR detection** — `VR_Init()` called with `VRApplication_Scene`. If SteamVR is running:
   - Headset + controllers detected
   - Compositor initialized
   - Overlay created for menus
   - Full 6DoF motion controls activated
6. **No VR?** — `VR_Init()` fails silently. `m_IsVREnabled = false`, game runs flat. No popups, no crashes.

---

## Controls

| Action | Default Binding |
|---|---|
| Primary fire (blue portal) | Right trigger |
| Secondary fire (orange portal) | Left trigger |
| Jump | A / Right touchpad press |
| Crouch | B / Left touchpad press |
| Use / Grab objects | Grip button |
| Reload | X / Y |
| Walk | Left thumbstick |
| Turn | Right thumbstick (left/right) |
| Recenter camera | Left stick press |
| Flashlight | Stick button |
| Next / Previous item | D-pad up / down |
| Reset VR position | Stick press |

---

## Config

Edit `Portal 2\VR\config.txt` while the game is running — changes apply live.

| Setting | Values | Default | Description |
|---|---|---|---|
| `AimMode` | 0, 1, 2 | 2 | 0=off, 1=crosshair, 2=laser sight |
| `SnapTurning` | true/false | false | Snap turn instead of smooth |
| `SnapTurnAngle` | float | 45.0 | Degrees per snap turn |
| `LeftHanded` | true/false | false | Swap controller roles |
| `TurnSpeed` | float | 0.15 | Smooth turn speed |
| `VRScale` | float | 43.2 | World scale factor |
| `IPDScale` | float | 1.0 | Interpupillary distance multiplier |
| `6DOF` | true/false | true | Enable positional tracking |
| `AntiAliasing` | 0, 2, 4, 8 | 0 | MSAA level |
| `RenderWindow` | 0/1 | 0 | Render a 3rd view for desktop window |
| `ViewmodelPosCustomOffset` | float XYZ | 0.0 | Custom viewmodel position offset |
| `ViewmodelAngCustomOffset` | float XYZ | 0.0 | Custom viewmodel angle offset |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Not loading in VR | Start SteamVR **before** launching Portal 2. Disable SteamVR Theater mode in Steam settings. |
| No audio | Run `Portal 2\portal2_dlc3\UpdateSoundCache.cmd` |
| Stuttering | Steam Settings → Shader Pre-Caching → Allow background Vulkan shaders |
| Crashing | Lower video settings, verify game files, reinstall the mod |
| Want flat mode back | Delete `d3d9.dll` from root + `bin\`, delete `VR\` folder |

---

## Building from source

Requirements: Visual Studio 2022 (v143), Windows 10 SDK (10.0.26100.0), DirectX SDK

```cmd
msbuild l4d2vr.sln /p:Configuration=Release /p:Platform=x86 /t:Build
```

---

## Credits

**v5.3.0 Maintained by** — [jimgranitex-eng](https://github.com/jimgranitex-eng) — auto-detect VR, zero-config launch, code cleanup, performance optimization.

Based on the original [portal2vr](https://github.com/Gistix/portal2vr) by Gistix, which itself was built on [l4d2vr](https://github.com/sd805/l4d2vr).

Uses code from VirtualFortress2, gmcl_openvr, [dxvk](https://github.com/TheIronWolfModding/dxvk/tree/vr-dx9-rel) (vr-dx9-rel), and source-sdk-2013.
